package assn07;

import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.HashSet;

public class PasswordManager<K,V> implements Map<K,V> {
    private static final String MASTER_PASSWORD = "YOUR PASSWORD HERE";
    private Account[] _passwords;

    private static int _size;

    public PasswordManager() {
        _passwords = new Account[50];
    }


    // TODO: put
    @Override
    public void put(K key, V value) {
        int hash = Math.floorMod(key.hashCode(), 50);
        Account fcheck = null;
        boolean added = false;

        if (_passwords[hash] == null){
            Account temp = new Account(key, value);
            _passwords[hash] = temp;
            added = true;
        }
        else {
            Account check = _passwords[hash];
            while (check.getNext() != null) {
                String checkS = (String) check.getWebsite();
                String checkK = (String) key;
                if(checkS.compareTo(checkK) == 0){
                    _passwords[hash].setPassword(value);
                    return;
                }
                check = check.getNext();

            }
                if (check.getNext() == null && check != null) {
                    String checkS = (String) check.getWebsite();
                    String checkK = (String) key;
                    if (checkS.compareTo(checkK) == 0) {
                        check.setPassword(value);
                    } else {
                        Account temp = new Account(key, value);
                        check.setNext(temp);
                    }
                }

        }
    }

    // TODO: get
    @Override
    public V get(K key) {
        return null;
    }

    // TODO: size
    @Override
    public int size() {
        int size = 0;
        for (int i = 0; i < getPasswords().length - 1; i++){
            Account curr = _passwords[i];
            if (_passwords[i] != null){
                size++;
                while(curr.getNext() != null){
                    size++;
                    curr = curr.getNext();
                }
            }
        }
        return size;
    }

    // TODO: keySet
    @Override
    public Set<K> keySet() {
        return null;
    }

    // TODO: remove
    @Override
    public V remove(K key) {
        return null;
    }

    // TODO: checkDuplicate
    @Override
    public List<K> checkDuplicate(V value) {
        return null;
    }

    // TODO: checkMasterPassword
    @Override
    public boolean checkMasterPassword(String enteredPassword) {
        return false;
    }

    /*
    Generates random password of input length
     */
    @Override
    public String generateRandomPassword(int length) {
        int leftLimit = 48; // numeral '0'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = length;
        Random random = new Random();

        String generatedString = random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        return generatedString;
    }

    /*
    Used for testing, do not change
     */
    public Account[] getPasswords() {
        return _passwords;
    }
}