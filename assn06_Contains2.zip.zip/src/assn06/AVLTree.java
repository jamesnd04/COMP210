package assn06;

public class AVLTree<T extends Comparable<T>> implements SelfBalancingBST<T> {
    // Fields
    private T _value;
    private AVLTree<T> _left;
    private AVLTree<T> _right;
    private int _height;
    private int _size;
    
    public AVLTree() {
        _value = null;
        _left = null;
        _right = null;
        _height = -1;
        _size = 0;
    }

    /**
     *
     * Rotates the tree left and returns
     * AVLTree root for rotated result.
     */
    
     private AVLTree<T> rotateLeft() {
         // You should implement left rotation and then use this 
         // method as needed when fixing imbalances.
    	 // TODO
         return null;
     }
    
    /**
     *
     * Rotates the tree right and returns
     * AVLTree root for rotated result.
     */ 
     
     private AVLTree<T> rotateRight() {
         // You should implement right rotation and then use this 
         // method as needed when fixing imbalances.
    	 // TODO
         return null;
     }

    @Override
    public boolean isEmpty() {
        return size() == 0;
    }

    @Override
    public int height() {
        return _height;
    }

    @Override
    public int size() {
        return _size;
    }

    @Override
    public SelfBalancingBST<T> insert(T element) {
        if(isEmpty()){
            _value = element;
            _right = new AVLTree<T>();
            _left = new AVLTree<T>();
            _size++;
            _height = Math.max(_left.height(), _right.height()) + 1;
        }
        else if(element.compareTo(_value) < 0){
            _left.insert(element);
            _size++;
            _height = Math.max(_left._height, _right._height) + 1;
        }
        else{
            _right.insert(element);
            _size++;
            _height = Math.max(_left._height, _right._height) + 1;
        }
        return this;
     }



    @Override
    public SelfBalancingBST<T> remove(T element) {
    	// TODO
        return null;
    }

    @Override
    public T findMin() {
         if (isEmpty()) {
             throw new RuntimeException("Illegal operation on empty tree");
         }
         if (_left.isEmpty()) {
             return _value;
         } else {
             return _left.findMin();
         }
    }

    @Override
    public T findMax() {
        if (isEmpty()) {
            throw new RuntimeException("Illegal operation on empty tree");
        }
        if (_right.isEmpty()) {
            return _value;
        } else {
            return _right.findMax();
        }
    }

    @Override
    public boolean contains(T element) {
    	if(isEmpty()){
        return false;
        }
        else if(element.compareTo(_value) < 0){
            return _left.contains(element);
        }
        else if(element.compareTo(_value) > 0){
            return _right.contains(element);
        }
        else if(element.compareTo(_value) == 0){
            return true;
        }
        return false;
    }

    @Override
    public T getValue() {
        return _value;
    }

    @Override
    public SelfBalancingBST<T> getLeft() {
        if (isEmpty()) {
            return null;
        }
        return _left;
    }

    @Override
    public SelfBalancingBST<T> getRight() {
        if (isEmpty()) {
            return null;
        }

         return _right;
    }

    public boolean hasChildren(){
         if(getLeft() == null){
             if(getRight() == null){
                 return false;}
             else{
                 return true;
             }
         }
        else if(getRight() == null){
            if(getLeft() == null){
                return false;
            }
            else{
            return true;
            }
        }
        else{
        return true;
        }
    }

}
