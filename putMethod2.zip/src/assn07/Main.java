package assn07;


import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String,String> passwordManager = new PasswordManager<>();

        passwordManager.put("AB","1");
        passwordManager.put("Apple","2");
        passwordManager.put("@C","4");
        passwordManager.put("AB","5");
        System.out.println("Expected 3, given: " + passwordManager.size());
        System.out.println("exit");

    }
}
